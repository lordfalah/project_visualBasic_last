-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2023 at 06:02 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parkir`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberCariAngka` (`_Cari` INT)  BEGIN
SELECT MemberID, NamaMember, NoKTP, Alamat, Deposit, Tipe, TglJoin FROM Member
WHERE
Deposit = _Cari
OR Tipe = _Cari;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberCariID` (`_MemberID` INT)  BEGIN
SELECT MemberID, NamaMember, NoKTP, Alamat, Deposit, Tipe, TglJoin FROM Member WHERE MemberID=_MemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberCariNama` (`_NamaMember` VARCHAR(255))  BEGIN
SELECT MemberID, NamaMember, NoKTP, Alamat, Deposit, Tipe, TglJoin FROM Member WHERE NamaMember=_NamaMember;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberCariText` (`_Cari` VARCHAR(255))  BEGIN
SELECT MemberID, NamaMember, NoKTP, Alamat, Deposit, Tipe, TglJoin FROM Member
WHERE
NamaMember LIKE CONCAT('%', _Cari, '%')
OR NoKTP LIKE CONCAT('%', _Cari, '%')
OR Alamat LIKE CONCAT('%', _Cari, '%');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberCariTglJoin` (`_TglJoin` DATE)  BEGIN
SELECT MemberID, NamaMember, NoKTP, Alamat, Deposit, Tipe, TglJoin FROM Member WHERE TglJoin=_TglJoin;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberDelete` (`_MemberID` INT)  BEGIN
DELETE FROM Member WHERE MemberID=_MemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberInsert` (`_NamaMember` VARCHAR(255), `_Alamat` VARCHAR(255), `_NoKTP` VARCHAR(255), `_Deposit` BIGINT, `_Tipe` INT, `_TglJoin` DATE)  BEGIN
INSERT INTO Member(NamaMember, Alamat, NoKTP, Deposit, Tipe, TglJoin) VALUES
(_NamaMember, _Alamat, _NoKTP, _Deposit, _Tipe, _TglJoin);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberSelect` ()  BEGIN
SELECT MemberID, NamaMember, NoKTP FROM Member;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberSelectAll` ()  BEGIN
SELECT MemberID, NamaMember, Alamat, NoKTP, Deposit, Tipe, TglJoin FROM Member;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MemberUpdate` (`_MemberID` INT, `_NamaMember` VARCHAR(255), `_Alamat` VARCHAR(255), `_NoKTP` VARCHAR(255), `_Deposit` BIGINT, `_Tipe` INT, `_TglJoin` DATE)  BEGIN
UPDATE Member SET NamaMember=_NamaMember, Alamat=_Alamat, NoKTP=_NoKTP, Deposit=_Deposit, Tipe=_Tipe, TglJoin=_TglJoin
WHERE MemberID=_MemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariMemberID` (`_NoPolisi` VARCHAR(255))  BEGIN
SELECT MemberID
FROM viewMemberMobil
WHERE
NoPolisi=_NoPolisi;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariMemberStatus` (`_MemberID` INT, `_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, TglKeluar, NoPolisi, MemberID, Status
FROM Parkir
WHERE MemberID=_MemberID AND Status=_Status
ORDER BY TglMasuk DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariNoPolisiStatus` (`_NoPolisi` VARCHAR(255), `_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, TglKeluar, NoPolisi, MemberID, RateParkir, FeePerJam, Status
FROM Parkir
WHERE NoPolisi=_NoPolisi AND Status=_Status
ORDER BY TglMasuk DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariRiwayatNoPolisi` (`_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, TglKeluar, NoPolisi, MemberID, Status
FROM Parkir
WHERE NoPolisi=_NoPolisi AND Status=_Status
ORDER BY TglMasuk DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariStatus` (`_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, TglKeluar, NoPolisi, MemberID, Status
FROM Parkir
WHERE Status=_Status
ORDER BY TglMasuk DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariStrukMasukStatus` (`_StrukID` INT, `_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, NoPolisi, MemberID, RateParkir, FeePerJam, Status
FROM Parkir
WHERE StrukID=_StrukID AND Status=_Status
ORDER BY StrukID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariStrukStatus` (`_StrukID` INT, `_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, TglKeluar, NoPolisi, MemberID, RateParkir, FeePerJam, Status
FROM Parkir
WHERE StrukID=_StrukID AND Status=_Status
ORDER BY StrukID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirCariText` (`_Text` VARCHAR(255), `_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk, TglKeluar, NoPolisi, MemberID, Status
FROM Parkir
WHERE
NoPolisi LIKE CONCAT('%', _Text, '%')
AND Status=_Status;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirDelete` (`_StrukID` INT)  BEGIN
DELETE FROM Parkir WHERE StrukID=_StrukID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirKeluar` (`_StrukID` INT, `_TglKeluar` DATETIME, `_Status` VARCHAR(1))  BEGIN
UPDATE Parkir SET TglKeluar=_TglKeluar, RateParkir=_RateParkir, FeePerJam=_FeePerJam, Status=_Status
WHERE StrukID=_StrukID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirKeluarNoStruk` (`_StrukID` INT, `_TglKeluar` DATETIME, `_FeeNoStruk` BIGINT, `_Status` VARCHAR(1))  BEGIN
UPDATE Parkir SET TglKeluar=_TglKeluar, FeeNoStruk=_FeeNoStruk, Status=_Status
WHERE StrukID=_StrukID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirMasuk` (`_TglMasuk` DATETIME, `_NoPolisi` VARCHAR(255), `_MemberID` INT, `_RateParkir` FLOAT, `_FeePerJam` BIGINT, `_Status` VARCHAR(1))  BEGIN
INSERT INTO Parkir(TglMasuk, NoPolisi, MemberID, RateParkir, FeePerJam, Status) VALUES
(_TglMasuk, _NoPolisi, _MemberID, _RateParkir, _FeePerJam, _Status);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ParkirStrukList` (`_Status` VARCHAR(1))  BEGIN
SELECT StrukID, TglMasuk
FROM Parkir
WHERE Status=_Status
ORDER BY StrukID DESC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `MemberID` int(10) UNSIGNED NOT NULL,
  `NamaMember` varchar(255) DEFAULT NULL,
  `Alamat` varchar(255) DEFAULT NULL,
  `NoKTP` varchar(255) DEFAULT NULL,
  `TglJoin` date DEFAULT NULL,
  `Tipe` int(11) DEFAULT NULL,
  `Deposit` bigint(20) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`MemberID`, `NamaMember`, `Alamat`, `NoKTP`, `TglJoin`, `Tipe`, `Deposit`) VALUES
(3, 'budi', NULL, 'aaaa', '2022-11-29', 2, 10000),
(4, 'sebudi', 'budiaaa', 'sdfsdf', '2022-12-01', 3, 10000),
(5, 'iwan', 'jl. satu', '23434554', '2022-12-08', 1, 4000000),
(6, 'iwan saja', 'jl. satu 100', '5467456354', '2022-12-08', 2, 190000),
(7, 'hanya iwan', 'jl. dua100', '4673444423', '2022-12-07', 1, 2000000),
(8, 'hanya iwan kok', 'jl. dua10', '555333', '2022-12-07', 3, 5000000);

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `MobilID` int(11) NOT NULL,
  `NoPolisi` varchar(255) DEFAULT NULL,
  `Catatan` varchar(255) DEFAULT NULL,
  `MemberID` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`MobilID`, `NoPolisi`, `Catatan`, `MemberID`) VALUES
(2, 'hj3345', 'asdas', 3),
(3, 'ha22222', 'dfgdfgd', 4),
(4, 'rt5456', 'fggh', 3),
(5, 'ty45645', 'dfggdf', 6),
(6, 'ww456546', 'fghfhf', 3),
(7, 'oo56756', 'dfgdfg', 6);

-- --------------------------------------------------------

--
-- Table structure for table `parkir`
--

CREATE TABLE `parkir` (
  `StrukID` int(11) NOT NULL,
  `TglMasuk` datetime DEFAULT NULL,
  `TglKeluar` datetime DEFAULT NULL,
  `NoPolisi` varchar(255) DEFAULT NULL,
  `MemberID` int(11) UNSIGNED DEFAULT NULL,
  `RateParkir` float UNSIGNED DEFAULT NULL,
  `FeePerJam` bigint(20) UNSIGNED DEFAULT NULL,
  `FeeNoStruk` bigint(20) UNSIGNED DEFAULT NULL,
  `Status` varchar(1) NOT NULL DEFAULT '0',
  `FeeParkir` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parkir`
--

INSERT INTO `parkir` (`StrukID`, `TglMasuk`, `TglKeluar`, `NoPolisi`, `MemberID`, `RateParkir`, `FeePerJam`, `FeeNoStruk`, `Status`, `FeeParkir`) VALUES
(4, '2022-12-15 11:45:16', NULL, 'ha22222', 4, 1, 2000, NULL, 'M', NULL),
(5, '2022-12-15 12:13:06', NULL, '', 0, 1, 2000, NULL, 'M', NULL),
(6, '2023-01-05 09:45:51', NULL, 'aaaaa', 0, 3, 3000, NULL, 'M', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewmembermobil`
-- (See below for the actual view)
--
CREATE TABLE `viewmembermobil` (
`MemberID` int(10) unsigned
,`NoPolisi` varchar(255)
);

-- --------------------------------------------------------

--
-- Structure for view `viewmembermobil`
--
DROP TABLE IF EXISTS `viewmembermobil`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewmembermobil`  AS SELECT `member`.`MemberID` AS `MemberID`, `mobil`.`NoPolisi` AS `NoPolisi` FROM (`member` join `mobil` on(`member`.`MemberID` = `mobil`.`MemberID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`MemberID`) USING BTREE;

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`MobilID`) USING BTREE,
  ADD KEY `FK_mobil_member` (`MemberID`) USING BTREE;

--
-- Indexes for table `parkir`
--
ALTER TABLE `parkir`
  ADD PRIMARY KEY (`StrukID`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `MemberID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mobil`
--
ALTER TABLE `mobil`
  MODIFY `MobilID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `parkir`
--
ALTER TABLE `parkir`
  MODIFY `StrukID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mobil`
--
ALTER TABLE `mobil`
  ADD CONSTRAINT `FK_mobil_member` FOREIGN KEY (`MemberID`) REFERENCES `member` (`MemberID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

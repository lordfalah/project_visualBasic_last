﻿Imports MySql.Data.MySqlClient

Public Class frmParkirKeluar
    Dim connString As String = "Server=127.0.0.1;Database=parkir;Uid=root;"

    Dim conn As MySqlConnection = New MySqlConnection(connString)
    Dim da As MySqlDataAdapter
    Dim dr As MySqlDataReader
    Dim sqlComm As MySqlCommand

    Dim ds As DataSet
    Dim dt As DataTable

    Dim rp As Long, fp As Long, jam As Long

    Private Function Koneksi(ByVal reqState As Boolean) As Boolean
        Dim ret As Boolean = True

        Try
            If reqState = True Then
                If conn.State = ConnectionState.Closed Then conn.Open()
            Else
                If conn.State = ConnectionState.Open Then conn.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, , "error")
            ret = False
        End Try

        Return ret
    End Function

    Private Sub ResetUI()
        txtNoPolisi.Text = ""
        txtStrukID.Text = ""
        txtMemberID.Text = ""
        txtTglMasuk.Text = ""
        txtTglKeluar.Text = ""
        txtRateParkir.Text = 0
        txtFeePerJam.Text = 0
        btnSimpan.Enabled = True
        txtBiayaParkir.Text = 0
        txtTanpaStruk.Text = 0
        txtTotalBiayaParkir.Text = 0
        txtCash.Text = 0
        txtKembalian.Text = 0
        chkTanpaStruk.Checked = False
        txtLamaParkir.Text = 0
    End Sub

    Private Function fillDGV() As Boolean
        Dim ret As Boolean = True

        If Koneksi(True) Then
            Try
                da = New MySqlDataAdapter("SELECT StrukID, TglMasuk, NoPolisi, RateParkir, FeePerJam FROM parkir", conn)
                ds = New DataSet

                Try
                    ds.Tables("dgvMember").Clear()
                Catch ex As Exception
                End Try

                da.Fill(ds, "dgvMember")
                dgv.DataSource = ds.Tables("dgvMember")
            Catch ex As Exception
                MsgBox(ex.Message, , "error")
                ret = False
            End Try
        Else
            ret = False
        End If

        Return ret
    End Function

    Private Sub SetupDGV()
        With dgv
            .Columns(0).HeaderText = "Nomor"
            .Columns(1).HeaderText = "Tanggal Masuk"
            .Columns(2).HeaderText = "No. Polisi"
            .Columns(3).HeaderText = "Rate Parkir"
            .Columns(4).HeaderText = "Fee Perjam"

            .Columns(0).Width = 60
            .Columns(1).Width = 150
        End With
    End Sub

    Private Sub frmParkirKeluar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ResetUI()
        fillDGV()
        SetupDGV()
    End Sub

    Private Sub chkTanpaStruk_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTanpaStruk.CheckedChanged
        If chkTanpaStruk.Checked = True Then
            txtTanpaStruk.Text = 15000
            txtNoPolisi.Enabled = True
            MessageBox.Show("Masukkan nomor polisi, akhiri dengan ENTER", "info", MessageBoxButtons.OK)
        Else
            txtTanpaStruk.Text = 0
            txtNoPolisi.Enabled = False
        End If
        HitungTotalParkir()
    End Sub

    Private Sub HitungTotalParkir()
        Dim bp As Long, ts As Long, tp As Long

        bp = Long.Parse(txtBiayaParkir.Text)
        ts = Long.Parse(txtTanpaStruk.Text)
        tp = bp + ts
        txtTotalBiayaParkir.Text = tp

    End Sub

    Private Sub HitungBiayaParkir()
        Dim bp As Long

        bp = rp * fp * jam
        txtBiayaParkir.Text = bp
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        ResetUI()
    End Sub

    Private Sub btnLoadNoStruk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadNoStruk.Click
        Dim lKode As String

        lKode = txtStrukID.Text

        If Koneksi(True) Then
            Try
                sqlComm = New MySqlCommand
                With sqlComm
                    .Connection = conn
                    .CommandText = "SP_ParkirCariStrukStatus"
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("_StrukID", lKode)
                    .Parameters.AddWithValue("_Status", "M")
                End With

                dt = New DataTable
                da = New MySqlDataAdapter(sqlComm)
                da.Fill(dt)

                If dt.Rows.Count = 0 Then
                    MsgBox("Tidak ditemukan", , "error")
                Else
                    For Each drow As DataRow In dt.Rows
                        txtNoPolisi.Text = drow.Item("NoPolisi").ToString()
                        txtStrukID.Text = drow.Item("StrukID").ToString()
                        txtTglMasuk.Text = drow.Item("TglMasuk").ToString()
                        txtMemberID.Text = drow.Item("MemberID").ToString()
                        txtRateParkir.Text = drow.Item("RateParkir").ToString()
                        txtFeePerJam.Text = drow.Item("FeePerJam").ToString()

                        txtTglKeluar.Text = Date.Now()

                        rp = drow.Item("RateParkir")
                        fp = drow.Item("FeePerJam")
                        jam = HitungJam()
                        txtLamaParkir.Text = jam
                        HitungBiayaParkir()
                        HitungTotalParkir()
                    Next
                End If
            Catch ex As Exception
                MsgBox(ex.Message, , "error")
            End Try
        End If
    End Sub

    Private Sub btnLoadNoPolisi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadNoPolisi.Click
        Dim lKode As String

        lKode = txtNoPolisi.Text

        If Koneksi(True) Then
            Try
                sqlComm = New MySqlCommand
                With sqlComm
                    .Connection = conn
                    .CommandText = "SP_ParkirCariNoPolisiStatus"
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("_NoPolisi", lKode)
                    .Parameters.AddWithValue("_Status", "M")
                End With

                dt = New DataTable
                da = New MySqlDataAdapter(sqlComm)
                da.Fill(dt)

                If dt.Rows.Count = 0 Then
                    MsgBox("Tidak ditemukan", , "error")
                Else
                    For Each drow As DataRow In dt.Rows
                        txtNoPolisi.Text = drow.Item("NoPolisi").ToString()
                        txtStrukID.Text = drow.Item("StrukID").ToString()
                        txtTglMasuk.Text = drow.Item("TglMasuk").ToString()
                        txtMemberID.Text = drow.Item("MemberID").ToString()
                        txtRateParkir.Text = drow.Item("RateParkir").ToString()
                        txtFeePerJam.Text = drow.Item("FeePerJam").ToString()

                        txtTglKeluar.Text = Date.Now()

                        rp = drow.Item("RateParkir")
                        fp = drow.Item("FeePerJam")
                        jam = HitungJam()
                        txtLamaParkir.Text = jam
                        HitungBiayaParkir()
                        HitungTotalParkir()
                    Next
                End If
            Catch ex As Exception
                MsgBox(ex.Message, , "error")
            End Try
        End If
    End Sub

    Private Function HitungJam() As Long
        Dim a As Date, b As Date, hasil As Long

        a = Date.Parse(txtTglMasuk.Text)
        b = Date.Parse(txtTglKeluar.Text)
        hasil = DateDiff(DateInterval.Hour, a, b)
        Return hasil
    End Function


    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        Close()
    End Sub
End Class
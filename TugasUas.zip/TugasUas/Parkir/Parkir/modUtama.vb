﻿Module modUtama
    Public PerusahaanNama As String = "PT. Parkir"
    Public PerusahaanAlamat As String = "Jl. Satu 100"
    Public PerusahaanTelp As String = "0981222345"

    Public RateParkir As Long = 1
    Public FeePerJam As Long = 2000
    Public FeeNoStruk As Long = 15000
End Module

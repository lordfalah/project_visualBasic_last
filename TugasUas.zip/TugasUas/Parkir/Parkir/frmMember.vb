﻿Imports MySql.Data.MySqlClient

Public Class frmMember
    Dim connString As String = "server=localhost;User Id=root;database=parkir"

    Dim conn As MySqlConnection = New MySqlConnection(connString)
    Dim da As MySqlDataAdapter
    Dim dr As MySqlDataReader
    Dim sqlComm As MySqlCommand

    Dim ds As DataSet
    Dim dt As DataTable
    Dim dv As DataView

    Private Function Koneksi(ByVal bReqState As Boolean) As Boolean
        Dim ret As Boolean = True

        Try
            If bReqState = True Then
                If conn.State = ConnectionState.Closed Then conn.Open()
            Else
                If conn.State = ConnectionState.Open Then conn.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, , "error")
            ret = False
        End Try

        Return ret
    End Function

    Private Sub SetupDGV()
        With dgv
            .Columns(0).HeaderText = "Nomor"
            .Columns(1).HeaderText = "Nama Member"
            .Columns(2).HeaderText = "No. KTP"

            .Columns(0).Width = 60
            .Columns(1).Width = 150
            .Columns(2).Width = 100
        End With
    End Sub

    Private Function fillDGV() As Boolean
        Dim ret As Boolean = True

        If Koneksi(True) Then
            Try
                da = New MySqlDataAdapter("SELECT MemberID, NamaMember, NoKTP FROM Member", conn)
                ds = New DataSet

                Try
                    ds.Tables("dgvMember").Clear()
                Catch ex As Exception
                End Try

                da.Fill(ds, "dgvMember")
                dgv.DataSource = ds.Tables("dgvMember")
            Catch ex As Exception
                MsgBox(ex.Message, , "error")
                ret = False
            End Try
        Else
            ret = False
        End If

        Return ret
    End Function

    Private Sub frmMember_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        fillDGV()
        SetupDGV()
    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmParkirKeluar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtTglMasuk = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.txtStrukID = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtFeePerJam = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtRateParkir = New System.Windows.Forms.TextBox()
        Me.txtNoPolisi = New System.Windows.Forms.TextBox()
        Me.txtMemberID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtBiayaParkir = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtCash = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtKembalian = New System.Windows.Forms.TextBox()
        Me.txtTanpaStruk = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtTotalBiayaParkir = New System.Windows.Forms.TextBox()
        Me.chkTanpaStruk = New System.Windows.Forms.CheckBox()
        Me.txtTglKeluar = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnLoadNoStruk = New System.Windows.Forms.Button()
        Me.btnLoadNoPolisi = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtLamaParkir = New System.Windows.Forms.TextBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtTglMasuk
        '
        Me.txtTglMasuk.Enabled = False
        Me.txtTglMasuk.Location = New System.Drawing.Point(796, 139)
        Me.txtTglMasuk.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTglMasuk.Name = "txtTglMasuk"
        Me.txtTglMasuk.Size = New System.Drawing.Size(252, 22)
        Me.txtTglMasuk.TabIndex = 96
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(639, 139)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 17)
        Me.Label2.TabIndex = 97
        Me.Label2.Text = "Tanggal Masuk"
        '
        'btnSimpan
        '
        Me.btnSimpan.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSimpan.Location = New System.Drawing.Point(1103, 353)
        Me.btnSimpan.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(407, 59)
        Me.btnSimpan.TabIndex = 83
        Me.btnSimpan.Text = "Keluar Parkir"
        Me.btnSimpan.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(599, 30)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(148, 29)
        Me.Label9.TabIndex = 95
        Me.Label9.Text = "Nomor Struk"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(1103, 427)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(405, 56)
        Me.btnReset.TabIndex = 85
        Me.btnReset.Text = "RESET"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'txtStrukID
        '
        Me.txtStrukID.Location = New System.Drawing.Point(756, 30)
        Me.txtStrukID.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStrukID.Name = "txtStrukID"
        Me.txtStrukID.Size = New System.Drawing.Size(179, 22)
        Me.txtStrukID.TabIndex = 94
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(639, 271)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 17)
        Me.Label8.TabIndex = 93
        Me.Label8.Text = "Fee PerJam"
        '
        'txtFeePerJam
        '
        Me.txtFeePerJam.Enabled = False
        Me.txtFeePerJam.Location = New System.Drawing.Point(796, 270)
        Me.txtFeePerJam.Margin = New System.Windows.Forms.Padding(4)
        Me.txtFeePerJam.Name = "txtFeePerJam"
        Me.txtFeePerJam.Size = New System.Drawing.Size(252, 22)
        Me.txtFeePerJam.TabIndex = 92
        Me.txtFeePerJam.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(639, 239)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 17)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Rate Parkir"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(597, 94)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 31)
        Me.Label3.TabIndex = 90
        Me.Label3.Text = "No Polisi"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(639, 206)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 17)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Nomor Member"
        '
        'txtRateParkir
        '
        Me.txtRateParkir.Enabled = False
        Me.txtRateParkir.Location = New System.Drawing.Point(796, 238)
        Me.txtRateParkir.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRateParkir.Name = "txtRateParkir"
        Me.txtRateParkir.Size = New System.Drawing.Size(252, 22)
        Me.txtRateParkir.TabIndex = 88
        Me.txtRateParkir.Text = "0"
        '
        'txtNoPolisi
        '
        Me.txtNoPolisi.Enabled = False
        Me.txtNoPolisi.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoPolisi.Location = New System.Drawing.Point(756, 94)
        Me.txtNoPolisi.Margin = New System.Windows.Forms.Padding(4)
        Me.txtNoPolisi.Name = "txtNoPolisi"
        Me.txtNoPolisi.Size = New System.Drawing.Size(179, 37)
        Me.txtNoPolisi.TabIndex = 87
        '
        'txtMemberID
        '
        Me.txtMemberID.Enabled = False
        Me.txtMemberID.Location = New System.Drawing.Point(796, 206)
        Me.txtMemberID.Margin = New System.Windows.Forms.Padding(4)
        Me.txtMemberID.Name = "txtMemberID"
        Me.txtMemberID.Size = New System.Drawing.Size(252, 22)
        Me.txtMemberID.TabIndex = 86
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(639, 418)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 17)
        Me.Label4.TabIndex = 99
        Me.Label4.Text = "Biaya Parkir"
        '
        'txtBiayaParkir
        '
        Me.txtBiayaParkir.Enabled = False
        Me.txtBiayaParkir.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBiayaParkir.Location = New System.Drawing.Point(796, 417)
        Me.txtBiayaParkir.Margin = New System.Windows.Forms.Padding(4)
        Me.txtBiayaParkir.Name = "txtBiayaParkir"
        Me.txtBiayaParkir.Size = New System.Drawing.Size(252, 37)
        Me.txtBiayaParkir.TabIndex = 98
        Me.txtBiayaParkir.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(1099, 243)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 17)
        Me.Label6.TabIndex = 101
        Me.Label6.Text = "Cash"
        '
        'txtCash
        '
        Me.txtCash.Location = New System.Drawing.Point(1256, 241)
        Me.txtCash.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCash.Name = "txtCash"
        Me.txtCash.Size = New System.Drawing.Size(252, 22)
        Me.txtCash.TabIndex = 100
        Me.txtCash.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(1099, 275)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 17)
        Me.Label7.TabIndex = 103
        Me.Label7.Text = "Kembalian"
        '
        'txtKembalian
        '
        Me.txtKembalian.Enabled = False
        Me.txtKembalian.Location = New System.Drawing.Point(1256, 273)
        Me.txtKembalian.Margin = New System.Windows.Forms.Padding(4)
        Me.txtKembalian.Name = "txtKembalian"
        Me.txtKembalian.Size = New System.Drawing.Size(252, 22)
        Me.txtKembalian.TabIndex = 102
        Me.txtKembalian.Text = "0"
        '
        'txtTanpaStruk
        '
        Me.txtTanpaStruk.Enabled = False
        Me.txtTanpaStruk.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTanpaStruk.Location = New System.Drawing.Point(796, 462)
        Me.txtTanpaStruk.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTanpaStruk.Name = "txtTanpaStruk"
        Me.txtTanpaStruk.Size = New System.Drawing.Size(252, 34)
        Me.txtTanpaStruk.TabIndex = 105
        Me.txtTanpaStruk.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(1099, 163)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(118, 17)
        Me.Label11.TabIndex = 108
        Me.Label11.Text = "Total biaya parkir"
        '
        'txtTotalBiayaParkir
        '
        Me.txtTotalBiayaParkir.Enabled = False
        Me.txtTotalBiayaParkir.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalBiayaParkir.Location = New System.Drawing.Point(1256, 161)
        Me.txtTotalBiayaParkir.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTotalBiayaParkir.Name = "txtTotalBiayaParkir"
        Me.txtTotalBiayaParkir.Size = New System.Drawing.Size(252, 37)
        Me.txtTotalBiayaParkir.TabIndex = 107
        Me.txtTotalBiayaParkir.Text = "0"
        '
        'chkTanpaStruk
        '
        Me.chkTanpaStruk.AutoSize = True
        Me.chkTanpaStruk.Location = New System.Drawing.Point(643, 462)
        Me.chkTanpaStruk.Margin = New System.Windows.Forms.Padding(4)
        Me.chkTanpaStruk.Name = "chkTanpaStruk"
        Me.chkTanpaStruk.Size = New System.Drawing.Size(107, 21)
        Me.chkTanpaStruk.TabIndex = 109
        Me.chkTanpaStruk.Text = "Struk Hilang"
        Me.chkTanpaStruk.UseVisualStyleBackColor = True
        '
        'txtTglKeluar
        '
        Me.txtTglKeluar.Enabled = False
        Me.txtTglKeluar.Location = New System.Drawing.Point(796, 171)
        Me.txtTglKeluar.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTglKeluar.Name = "txtTglKeluar"
        Me.txtTglKeluar.Size = New System.Drawing.Size(252, 22)
        Me.txtTglKeluar.TabIndex = 110
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(639, 171)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(105, 17)
        Me.Label10.TabIndex = 111
        Me.Label10.Text = "Tanggal Keluar"
        '
        'btnLoadNoStruk
        '
        Me.btnLoadNoStruk.Location = New System.Drawing.Point(944, 26)
        Me.btnLoadNoStruk.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLoadNoStruk.Name = "btnLoadNoStruk"
        Me.btnLoadNoStruk.Size = New System.Drawing.Size(71, 31)
        Me.btnLoadNoStruk.TabIndex = 112
        Me.btnLoadNoStruk.Text = "Search"
        Me.btnLoadNoStruk.UseVisualStyleBackColor = True
        '
        'btnLoadNoPolisi
        '
        Me.btnLoadNoPolisi.Location = New System.Drawing.Point(944, 94)
        Me.btnLoadNoPolisi.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLoadNoPolisi.Name = "btnLoadNoPolisi"
        Me.btnLoadNoPolisi.Size = New System.Drawing.Size(71, 31)
        Me.btnLoadNoPolisi.TabIndex = 113
        Me.btnLoadNoPolisi.Text = "Load"
        Me.btnLoadNoPolisi.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(639, 377)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(119, 17)
        Me.Label12.TabIndex = 115
        Me.Label12.Text = "Lama parkir (jam)"
        '
        'txtLamaParkir
        '
        Me.txtLamaParkir.Enabled = False
        Me.txtLamaParkir.Location = New System.Drawing.Point(796, 376)
        Me.txtLamaParkir.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLamaParkir.Name = "txtLamaParkir"
        Me.txtLamaParkir.Size = New System.Drawing.Size(252, 22)
        Me.txtLamaParkir.TabIndex = 114
        Me.txtLamaParkir.Text = "0"
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToDeleteRows = False
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(51, 72)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv.Name = "dgv"
        Me.dgv.ReadOnly = True
        Me.dgv.Size = New System.Drawing.Size(488, 274)
        Me.dgv.TabIndex = 116
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(583, 330)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(197, 31)
        Me.Label13.TabIndex = 117
        Me.Label13.Text = "Tanggal Keluar"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(51, 389)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(202, 46)
        Me.Button1.TabIndex = 118
        Me.Button1.Text = "Reload"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmParkirKeluar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1537, 532)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtLamaParkir)
        Me.Controls.Add(Me.btnLoadNoPolisi)
        Me.Controls.Add(Me.btnLoadNoStruk)
        Me.Controls.Add(Me.txtTglKeluar)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.chkTanpaStruk)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtTotalBiayaParkir)
        Me.Controls.Add(Me.txtTanpaStruk)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtKembalian)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtCash)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtBiayaParkir)
        Me.Controls.Add(Me.txtTglMasuk)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnSimpan)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.txtStrukID)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtFeePerJam)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtRateParkir)
        Me.Controls.Add(Me.txtNoPolisi)
        Me.Controls.Add(Me.txtMemberID)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmParkirKeluar"
        Me.Text = "frmParkirKeluar"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtTglMasuk As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnSimpan As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents txtStrukID As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtFeePerJam As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtRateParkir As System.Windows.Forms.TextBox
    Friend WithEvents txtNoPolisi As System.Windows.Forms.TextBox
    Friend WithEvents txtMemberID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtBiayaParkir As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtCash As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtKembalian As System.Windows.Forms.TextBox
    Friend WithEvents txtTanpaStruk As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtTotalBiayaParkir As System.Windows.Forms.TextBox
    Friend WithEvents chkTanpaStruk As System.Windows.Forms.CheckBox
    Friend WithEvents txtTglKeluar As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnLoadNoStruk As System.Windows.Forms.Button
    Friend WithEvents btnLoadNoPolisi As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtLamaParkir As System.Windows.Forms.TextBox
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
